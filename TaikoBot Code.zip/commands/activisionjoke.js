const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('Valoramos la diversidad y nos esforzamos por fomentar un lugar de trabajo que ofrezca inclusión para todos.');
               message.channel.send('menos las mujeres');
               message.channel.send('XD');

}

module.exports.help = {
  name:"activision"
}
