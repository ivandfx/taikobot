const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://lh3.googleusercontent.com/-WwPgQjGRq4Q/YPfx0rxNGUI/AAAAAAAAB3M/r7qhQ_LiwRcbI6RxAfE0zcmTNY7wNv4bwCLcBGAsYHQ/s16000/E6zolmhWYAIrKRj.jpg');
               message.channel.send('xd');

}

module.exports.help = {
  name:"jesucristogamer"
}
