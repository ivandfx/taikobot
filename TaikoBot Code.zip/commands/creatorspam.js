const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('Todas las redes de mi creador en https://linktr.ee/dankunex');
}

module.exports.help = {
  name:"creator"
}
