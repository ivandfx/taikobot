const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('Encuentra el error');
               message.channel.send('...');
               message.channel.send('https://1.bp.blogspot.com/-9SdVyZnyJBI/YPgfFplYEnI/AAAAAAAAB30/2I7OtrP9BnYIycFPqqimxQ8PomoVt5kpwCLcBGAsYHQ/s0/E60A-04XIAM6RAH.png');

}

module.exports.help = {
  name:"errorgame"
}
