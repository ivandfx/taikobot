const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('¿Acabas de decir "El pepe"? No puedo con esta pesadilla, sacadme de aquí porfavor :c');
}

module.exports.help = {
  name:"elpepe"
}
