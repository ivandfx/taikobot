const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('Arigato');
}

module.exports.help = {
  name:"nya"
}
