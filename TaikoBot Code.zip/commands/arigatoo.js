const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://lh3.googleusercontent.com/-6jmoqMyb1xk/YPgZ_4O3TAI/AAAAAAAAB3g/wiybU5_qURg7ox70vZviL5Tm7SAC1YuYgCLcBGAsYHQ/s16000/ox5rj6quc6w61.jpg');
}

module.exports.help = {
  name:"arigato"
}
