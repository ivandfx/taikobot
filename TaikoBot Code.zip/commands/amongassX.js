const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://1.bp.blogspot.com/-RqGkEX-wFOU/YPgcHIQN9WI/AAAAAAAAB3s/2Jfruvhxmgk-nkkx765Wwrlkyf_Pu-JbQCLcBGAsYHQ/s128/image0.gif');
               message.channel.send('da butt looks sus');
}

module.exports.help = {
  name:"amogass"
}
