const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('No');
}

module.exports.help = {
  name:"ulovme?"
}
