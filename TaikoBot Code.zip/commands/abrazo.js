const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://1.bp.blogspot.com/-303sXvGZzp0/YP17nMaCzoI/AAAAAAAAB4Q/-uihjz27QxYxh7UugNc6XaLVJ8OFv_xlQCLcBGAsYHQ/s600/Captura%2Bde%2Bpantalla%2B2021-07-25%2B165623.png');
}

module.exports.help = {
  name:"abrazo"
}
