const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('¡Buenas noches!');
}

module.exports.help = {
  name:"gudnai"
}
