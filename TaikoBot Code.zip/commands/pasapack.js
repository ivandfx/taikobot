const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://minecraftdry.com/wp-content/uploads/2020/11/MeineKraft-fanmade-para-minecraft-1.17.jpg');
               message.channel.send('No olvides que soy Español');
               message.channel.send('XD');            
}

module.exports.help = {
  name:"pasapack"
}
