const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://lh3.googleusercontent.com/-0lTSdm85jBQ/YPfzD6a9rCI/AAAAAAAAB3U/tv-xj4-AymchqtipSB10eQqPIjdBM7nhwCLcBGAsYHQ/s16000/D-Kk7pDWwAIFGZQ');
}

module.exports.help = {
  name:"banderadelasenfermedades"
}
