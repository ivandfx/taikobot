const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('Ni idea, pregúntale a @Es la hora de la paja#3659');
}

module.exports.help = {
  name:"paja"
}
