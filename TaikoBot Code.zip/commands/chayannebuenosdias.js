const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
               message.channel.send('https://lh3.googleusercontent.com/-TtpMGihDOyA/YPgZ_g_XEyI/AAAAAAAAB3c/vSbVHDmeMhQGhlEn0BDmTrGZR0eg1oWIQCLcBGAsYHQ/s16000/EwXbKc-XEAERLVK.jpg');
}

module.exports.help = {
  name:"chayanne"
}
